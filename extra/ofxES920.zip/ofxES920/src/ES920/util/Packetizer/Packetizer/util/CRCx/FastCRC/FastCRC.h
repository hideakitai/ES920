#pragma once
#ifndef HT_UTIL_FASTCRC_H
#define HT_UTIL_FASTCRC_H

#if defined(KINETISK)
#include "FastCRChw.h"
#else
#include "FastCRCsw.h"
#endif

#endif // HT_UTIL_FASTCRC_H
